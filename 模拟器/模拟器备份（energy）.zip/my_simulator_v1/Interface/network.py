# -*-coding:utf-8-*-
import copy
import math
import collections
import numpy as np

# 网络参数，剪枝率
class NetworkGraph:
    def __init__(self, hardware_config, layer_config_list, quantize_config_list, input_index_list, reuse_config_list, prune_config_list, input_params):
        super(NetworkGraph, self).__init__()
        # same length for layer_config_list , quantize_config_list and input_index_list
        assert len(layer_config_list) == len(quantize_config_list)
        assert len(layer_config_list) == len(input_index_list)

        self.hardware_config = copy.deepcopy(hardware_config)
        self.layer_config_list = copy.deepcopy(layer_config_list)
        self.quantize_config_list = copy.deepcopy(quantize_config_list)
        self.reuse_config_list = copy.deepcopy(reuse_config_list)
        self.prune_config_list = copy.deepcopy(prune_config_list)
        self.input_index_list = copy.deepcopy(input_index_list)
        self.input_params = copy.deepcopy(input_params)

        self.base_size = int(self.input_params['input_shape'][2] / (self.input_params['input_shape'][2] / (self.hardware_config['xbar_size'] / 64) / self.input_params['input_size_min']))  # 针对feature_map前几层滑动次数过多适当提高并行度
        self.OU_size = [8, 8]

        self.net_info = []
        self.net_bit_weights = []

    def set_reuse_and_prune_ratio(self):
        layer_number = 0
        for i in range(0, len(self.layer_config_list)):
            if self.net_info[i]['type'] == 'conv' or self.net_info[i]['type'] == 'fc':
                self.net_info[i]['reuse_ratio'] = 1.0 - self.reuse_config_list[layer_number]
                self.net_info[i]['prune_ratio'] = 1.0 - self.prune_config_list[layer_number]
                layer_number = layer_number + 1
                print(str(layer_number) + ' reuse_ratio: ' + str(self.net_info[i]['reuse_ratio']) + ' prune_ratio: ' + str(self.net_info[i]['prune_ratio']))

    def get_weights(self):
        net_bit_weights = []
        for i in range(0, len(self.layer_config_list)):
            bit_weights = collections.OrderedDict()
            if self.net_info[i]['type'] == 'conv' or self.net_info[i]['type'] == 'fc':
                complete_bar_row = math.ceil(self.net_info[i]['OU_row_number'] / math.floor(self.hardware_config['xbar_size'] / self.OU_size[0]))
                complete_bar_column = math.ceil(self.net_info[i]['OU_column_number'] / math.floor(self.hardware_config['xbar_size'] / self.OU_size[1]))
                self.net_info[i]['Crossbar_number'] = complete_bar_row * complete_bar_column
                for j in range(0, self.net_info[i]['Crossbar_number']):
                    bit_weights[f'split{i}_weight{j}'] = np.ones((self.hardware_config['xbar_size'], self.hardware_config['xbar_size']))  # 暂且用1代表每个ceil已被使用，暂不考虑每个ceil具体的值
            net_bit_weights.append(bit_weights)

        self.net_bit_weights = net_bit_weights

    def get_structure(self):
        net_info = []
        input_size = [0] * len(self.layer_config_list)
        output_size = [0] * len(self.layer_config_list)
        for i in range(0, len(self.layer_config_list)):
            layer_info = collections.OrderedDict()
            layer_info['Multiple'] = 1
            layer_info['reuse_ratio'] = 0.0
            layer_info['prune_ratio'] = 0.0
            layer_info['OU_row_number'] = 0
            layer_info['OU_column_number'] = 0
            layer_info['Crossbar_number'] = 0
            layer_info['PE_number'] = 0

            if self.layer_config_list[i]['type'] == 'conv':
                layer_info['type'] = 'conv'
                layer_info['Inputchannel'] = self.layer_config_list[i]['in_channels']
                layer_info['Outputchannel'] = self.layer_config_list[i]['out_channels']
                layer_info['Kernelsize'] = self.layer_config_list[i]['kernel_size']
                layer_info['Stride'] = self.layer_config_list[i]['stride']
                layer_info['Padding'] = self.layer_config_list[i]['padding']

                layer_info['OU_row_number'] = math.ceil(self.layer_config_list[i]['in_channels'] * self.layer_config_list[i]['kernel_size'] * self.layer_config_list[i]['kernel_size'] / self.OU_size[0])
                layer_info['OU_column_number'] = math.ceil(self.layer_config_list[i]['out_channels'] * self.quantize_config_list[i]['weight_bit'] / self.hardware_config['weight_bit'] / self.OU_size[1])

                layer_info['reuse_ratio'] = self.layer_config_list[i]['reuse_ratio']
                layer_info['prune_ratio'] = self.layer_config_list[i]['prune_ratio']

                if i == 0:
                    input_size[i] = self.input_params['input_shape'][2]
                else:
                    input_size[i] = output_size[i + self.input_index_list[i][0]]
                output_size[i] = int((input_size[i] + 2 * self.layer_config_list[i]['padding'] - (self.layer_config_list[i]['kernel_size'] - 1)) / self.layer_config_list[i]['stride'])
                layer_info['Inputsize'] = [input_size[i], input_size[i]]
                layer_info['Outputsize'] = [output_size[i], output_size[i]]
                layer_info['Multiple'] = math.ceil(output_size[i] / self.base_size)

            elif self.layer_config_list[i]['type'] == 'fc':
                layer_info['type'] = 'fc'
                layer_info['Inputchannel'] = self.layer_config_list[i]['in_features']
                layer_info['Outputchannel'] = self.layer_config_list[i]['out_features']

                layer_info['OU_row_number'] = math.ceil(self.layer_config_list[i]['in_features'] / self.OU_size[0])
                layer_info['OU_column_number'] = math.ceil(self.layer_config_list[i]['out_features'] * self.quantize_config_list[i]['weight_bit'] / self.hardware_config['weight_bit'] / self.OU_size[1])

                layer_info['reuse_ratio'] = self.layer_config_list[i]['reuse_ratio']
                layer_info['prune_ratio'] = self.layer_config_list[i]['prune_ratio']

            elif self.layer_config_list[i]['type'] == 'pooling':
                layer_info['type'] = 'pooling'
                layer_info['Inputchannel'] = self.layer_config_list[i]['in_channels']
                layer_info['Outputchannel'] = self.layer_config_list[i]['out_channels']
                layer_info['Kernelsize'] = self.layer_config_list[i]['kernel_size']
                layer_info['Stride'] = self.layer_config_list[i]['stride']
                layer_info['Padding'] = self.layer_config_list[i]['padding']

                input_size[i] = output_size[i + self.input_index_list[i][0]]
                output_size[i] = int(input_size[i] / self.layer_config_list[i]['stride'])
                layer_info['Inputsize'] = [input_size[i], input_size[i]]
                layer_info['Outputsize'] = [output_size[i], output_size[i]]
                layer_info['Multiple'] = math.ceil(output_size[i] / self.base_size)

            elif self.layer_config_list[i]['type'] == 'relu':
                layer_info['type'] = 'relu'
                input_size[i] = output_size[i + self.input_index_list[i][0]]
                output_size[i] = input_size[i]

            elif self.layer_config_list[i]['type'] == 'view':
                layer_info['type'] = 'view'

            elif self.layer_config_list[i]['type'] == 'bn':
                layer_info['type'] = 'bn'
                layer_info['features'] = self.layer_config_list[i]['features']
                input_size[i] = output_size[i + self.input_index_list[i][0]]
                output_size[i] = input_size[i]

            elif self.layer_config_list[i]['type'] == 'element_sum':
                layer_info['type'] = 'element_sum'
                input_size[i] = output_size[i + self.input_index_list[i][0]]
                output_size[i] = input_size[i]

            else:
                assert 0, f'not support {self.layer_config_list[i]["type"]}'

            layer_info['Inputbit'] = (self.quantize_config_list[i]['activation_bit'])
            layer_info['Weightbit'] = int(self.quantize_config_list[i]['weight_bit'])
            if i != len(self.layer_config_list) - 1:
                layer_info['Outputbit'] = int(self.quantize_config_list[i+1]['activation_bit'])
            else:
                layer_info['Outputbit'] = int(self.quantize_config_list[i]['activation_bit'])
            layer_info['weight_cycle'] = math.ceil(self.quantize_config_list[i]['weight_bit'] / self.hardware_config['weight_bit'])
            if 'input_index' in self.layer_config_list[i]:
                layer_info['Inputindex'] = self.layer_config_list[i]['input_index']
            else:
                layer_info['Inputindex'] = [-1]
            layer_info['Outputindex'] = [1]

            net_info.append(layer_info)

        self.net_info = net_info


def get_net(hardware_config, cate, num_classes, mode):
    # initial config
    if hardware_config is None:
        hardware_config = {'xbar_size': 256, 'input_bit': 8, 'weight_bit': 8, 'quantize_bit': 8}
    # layer_config_list, quantize_config_list, and input_index_list
    layer_config_list = []
    quantize_config_list = []
    input_index_list = []
    reuse_config_list = []
    prune_config_list = []

    # layer by layer
    assert cate in ['LeNet','VGG16', 'VGG8', 'AlexNet','ZFNet','ResNet']
    if cate.startswith('LeNet'):
        layer_config_list.append({'type': 'conv', 'in_channels': 1, 'out_channels': 6, 'kernel_size': 5, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 6, 'out_channels': 6, 'kernel_size': 2, 'stride': 2, 'padding': 0})
        layer_config_list.append({'type': 'conv', 'in_channels': 6, 'out_channels': 16, 'kernel_size': 5, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 16, 'out_channels': 16, 'kernel_size': 2, 'stride': 2, 'padding': 0})
        layer_config_list.append({'type': 'conv', 'in_channels': 16, 'out_channels': 120, 'kernel_size': 5, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 120, 'out_features': 84, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'fc', 'in_features': 84, 'out_features': 10, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 0.85})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 3.44})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.53})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 1.48})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.76})

        prune_config_list = [1.0, 1.0, 1.0,1.0,1.0]
        reuse_config_list = [1.0, 1.0, 1.0,1.0,1.0]

        if mode == 'shape':  # 保留的，改成1就行
            prune_config_list = [1, 0.5, 0.51,1,1]  # 2.26
            # prune_config_list = [1.0, 1.0, 1.0,1,1]  # 2.26

    elif cate.startswith('AlexNet'):
        layer_config_list.append({'type': 'conv', 'in_channels': 3, 'out_channels': 96, 'kernel_size': 11, 'stride': 4, 'padding': 2, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 96, 'out_channels': 96, 'kernel_size': 3, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 96, 'out_channels': 256, 'kernel_size': 5, 'stride': 1, 'padding': 2, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 384, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 384, 'out_channels': 384, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 384, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 256*6*6, 'out_features': 4096, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'fc', 'in_features': 4096, 'out_features': 4096, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'fc', 'in_features': 4096, 'out_features': 10, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.54})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 3.42})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.42})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.50})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.85})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})



        prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,1.0,1.0,1.0]
        reuse_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,1.0,1.0,1.0]

        if mode == 'shape':  # 保留的，改成1就行
            prune_config_list = [1.0, 0.35, 0.5, 0.45, 0.5, 1.0, 1.0,1.0]
            # prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
            # 2.26

    elif cate.startswith('ZFNet'):
        layer_config_list.append({'type': 'conv', 'in_channels': 3, 'out_channels': 48, 'kernel_size': 7, 'stride': 2, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 48, 'out_channels': 48, 'kernel_size': 3, 'stride': 2, 'padding': 1})

        layer_config_list.append({'type': 'conv', 'in_channels': 48, 'out_channels': 128, 'kernel_size': 5, 'stride': 2, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 192, 'kernel_size': 3, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 192, 'out_channels': 192, 'kernel_size': 3, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 192, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 128*6*6, 'out_features': 2048, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'fc', 'in_features': 2048, 'out_features': 2048, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'fc', 'in_features': 2048, 'out_features': 10, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.86})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.75})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.28})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.26})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.85})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})  #
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})



        prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,1.0,1.0,1.0]
        reuse_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,1.0,1.0,1.0]

        if mode == 'shape':  # 保留的，改成1就行
            prune_config_list = [1.0, 0.22, 0.5, 0.5, 0.5, 1.0, 1.0,1.0]
            # prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
            # 2.26

    elif cate.startswith('VGG16'):
        layer_config_list.append({'type': 'conv', 'in_channels': 3, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 512, 'out_features': 10, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.07})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.5})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.84})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.75})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.89})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.75})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.25})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.87})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.82})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.75})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.79})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.31})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.25})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 3})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0,1.0]
        reuse_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0,1.0]

        if 'shape' in mode:  # 保留的，改成1就行
            prune_config_list = [1.0, 6.0 / 10, 7.0 / 10.0, 4.0 / 10.0, 6.0 / 10.0,
                                 4.0 / 10.0,4.0 / 10.0, 6.0 / 10.0,4.0 / 10.0,
                                 15.0/100.0,15.0/100.0,15.0/100.0,15.0/100.0,1]  # 2.26

    elif cate.startswith('VGG8'):
        layer_config_list.append({'type': 'conv', 'in_channels': 3, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 1024, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 1024, 'out_channels': 1024, 'kernel_size': 2, 'stride': 2, 'padding': 0})

        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 1024, 'out_features': 10, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})

        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.03})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 4.61})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.85})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.75})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.76})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0,1.0]
        reuse_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0,1.0]

        if mode == 'shape':  # 保留的，改成1就行
            prune_config_list = [1,0.4,0.45,0.4,0.45,0.4,0.45,1]
            # prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
            #                      1.0, 1.0, 1.0]
            # 2.26

    elif cate.startswith('ResNet'):
        layer_config_list.append({'type': 'conv', 'in_channels': 3, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        # block 1
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -4]})
        layer_config_list.append({'type': 'relu'})
        # block 2
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 64, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -4]})
        layer_config_list.append({'type': 'relu'})
        # block 3
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 128, 'kernel_size': 3, 'stride': 2, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'conv', 'in_channels': 64, 'out_channels': 128, 'kernel_size': 1, 'stride': 2, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0, 'input_index': [-4]})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -2]})
        layer_config_list.append({'type': 'relu'})
        # block 4
        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 128, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -4]})
        layer_config_list.append({'type': 'relu'})
        # block 5
        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 256, 'kernel_size': 3, 'stride': 2, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'conv', 'in_channels': 128, 'out_channels': 256, 'kernel_size': 1, 'stride': 2, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0, 'input_index': [-4]})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -2]})
        layer_config_list.append({'type': 'relu'})
        # block 6
        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 256, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -4]})
        layer_config_list.append({'type': 'relu'})
        # block 7
        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 512, 'kernel_size': 3, 'stride': 2, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'conv', 'in_channels': 256, 'out_channels': 512, 'kernel_size': 1, 'stride': 2, 'padding': 0, 'reuse_ratio': 0.0, 'prune_ratio': 0.0, 'input_index': [-4]})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -2]})
        layer_config_list.append({'type': 'relu'})
        # block 8
        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'relu'})
        layer_config_list.append({'type': 'conv', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 3, 'stride': 1, 'padding': 1, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})
        layer_config_list.append({'type': 'element_sum', 'input_index': [-1, -4]})
        layer_config_list.append({'type': 'relu'})

        # output
        layer_config_list.append({'type': 'pooling', 'mode': 'MAX', 'in_channels': 512, 'out_channels': 512, 'kernel_size': 4, 'stride': 4, 'padding': 0})
        layer_config_list.append({'type': 'view'})
        layer_config_list.append({'type': 'fc', 'in_features': 512, 'out_features': num_classes, 'reuse_ratio': 0.0, 'prune_ratio': 0.0})

        prune_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0]
        reuse_config_list = [1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0, 1.0, 1.0, 1.0, 1.0,
                             1.0]

        if mode == 'SRE':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
        if mode == 'shape':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 5.335})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.257})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.3584})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.6358})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.6666})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 7.4844})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.9522})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.494})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.5962})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.8088})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.6522})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.2434})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.3826})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.2976})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.1206})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 7.4375})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.324})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.06})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 6.7844})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 7.25})#
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})

        if mode == 'shape':  # 保留的，改成1就行
            prune_config_list = [0.55,0.19,0.5,0.47,0.5,
                                 0.5, 0.5, 0.5,0.5, 0.5,
                                 0.5, 0.5, 0.5,0.49,0.50,
                                 0.5, 0.5, 0.42,0.11,0.5,
                                 1]  # 2.26
    else:
        assert 0, f'not support {cate}'

    for i in range(len(layer_config_list)):
        if mode == 'naive':
            quantize_config_list.append({'weight_bit': 8, 'activation_bit': 8})
        if 'input_index' in layer_config_list[i]:
            input_index_list.append(layer_config_list[i]['input_index'])
        else:
            input_index_list.append([-1])

    input_size_min = 8
    if cate == 'VGG16':
        input_size_min = 1
        input_params = {'activation_bit': 8, 'input_shape': (1, 3, 32, 32), 'input_size_min': input_size_min}
    elif cate == 'ResNet':
        input_size_min = 4
        input_params = {'activation_bit': 8, 'input_shape': (1, 3, 32, 32), 'input_size_min': input_size_min}
    elif cate == 'LeNet':
        input_size_min = 8
        input_params = {'activation_bit': 8, 'input_shape': (1, 1, 32, 32), 'input_size_min': input_size_min}
    elif cate == 'VGG8':
        input_size_min = 8
        input_params = {'activation_bit': 8, 'input_shape': (1, 3, 32, 32), 'input_size_min': input_size_min}
    elif cate == 'AlexNet':
        input_size_min = 4
        input_params = {'activation_bit': 8, 'input_shape': (1, 3, 224, 224), 'input_size_min': input_size_min}
    elif cate == 'ZFNet':
        input_size_min = 4
        input_params = {'activation_bit': 8, 'input_shape': (1, 3, 224, 224), 'input_size_min': input_size_min}


    # add bn for every conv
    if mode == 'naive' :
        if cate != 'ResNet':
            L = len(layer_config_list)
            for i in range(L-1, -1, -1):
                if layer_config_list[i]['type'] == 'conv':
                    layer_config_list.insert(i+1, {'type': 'bn', 'features': layer_config_list[i]['out_channels']})
                    quantize_config_list.insert(i+1, {'weight_bit': 8, 'activation_bit': 8})
                    input_index_list.insert(i+1, [-1])
                    # conv层后面加了一层bn，所以这一层相对他后面的层的相对层数差要加一
                    for j in range(i + 2, len(layer_config_list), 1):
                        for relative_input_index in range(len(input_index_list[j])):
                            if j + input_index_list[j][relative_input_index] < i + 1:
                                input_index_list[j][relative_input_index] -= 1
        else:
            L = len(layer_config_list)
            for i in range(L - 1, -1, -1):
                if layer_config_list[i]['type'] == 'conv' and layer_config_list[i+1]['type'] == 'element_sum' and (layer_config_list[i]['out_channels']//layer_config_list[i]['in_channels']==2):
                    layer_config_list.insert(i + 1, {'type': 'bn', 'features': layer_config_list[i]['out_channels']})
                    quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': 8})
                    input_index_list.insert(i + 1, [-1])
                    # conv层后面加了一层bn，所以这一层相对他后面的层的相对层数差要加一
                    for j in range(i + 2, len(layer_config_list), 1):
                        for relative_input_index in range(len(input_index_list[j])):
                            if j + input_index_list[j][relative_input_index] < i + 1:
                                input_index_list[j][relative_input_index] -= 1
    elif mode != 'naive':
        L = len(layer_config_list)
        LeNet_bn = [1.24,3.78,6.5]
        AlexNet_bn = [4.85,5.50,6.42,3.42,4.54]
        ZFNet_bn = [4.85,5.26,6.28,5.75,4.86]
        VGG16_bn = [4.25,4.31,5.79,5.75,6.82,6.87,4.25,6.76,6.89,5.75,6.84,6.5,6.07]
        VGG8_bn = [5,5,6.76,5.75,6.85,4.61,6.03]
        ResNet_bn = [6.06,6.49,6.38]
        t = 0
        if cate != 'ResNet':
            for i in range(L - 1, -1, -1):
                if layer_config_list[i]['type'] == 'conv':
                    layer_config_list.insert(i + 1, {'type': 'bn', 'features': layer_config_list[i]['out_channels']})
                    if cate == 'LeNet':
                        quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': LeNet_bn[t]})
                        t += 1
                    elif cate == 'AlexNet':
                        quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': AlexNet_bn[t]})
                        t += 1
                    elif cate == 'VGG8':
                        quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': VGG8_bn[t]})
                        t += 1
                    elif cate == 'VGG16':
                        quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': VGG16_bn[t]})
                        t += 1
                    elif cate == 'ZFNet':
                        quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': ZFNet_bn[t]})
                        t += 1
                    input_index_list.insert(i + 1, [-1])
                    # conv层后面加了一层bn，所以这一层相对他后面的层的相对层数差要加一
                    for j in range(i + 2, len(layer_config_list), 1):
                        for relative_input_index in range(len(input_index_list[j])):
                            if j + input_index_list[j][relative_input_index] < i + 1:
                                input_index_list[j][relative_input_index] -= 1
        else:
            for i in range(L - 1, -1, -1):
                if layer_config_list[i]['type'] == 'conv' and layer_config_list[i+1]['type'] == 'element_sum' and (layer_config_list[i]['out_channels']//layer_config_list[i]['in_channels']==2):
                    layer_config_list.insert(i + 1, {'type': 'bn', 'features': layer_config_list[i]['out_channels']})
                    quantize_config_list.insert(i + 1, {'weight_bit': 8, 'activation_bit': ResNet_bn[t]})
                    t += 1
                    input_index_list.insert(i + 1, [-1])
                    # conv层后面加了一层bn，所以这一层相对他后面的层的相对层数差要加一
                    for j in range(i + 2, len(layer_config_list), 1):
                        for relative_input_index in range(len(input_index_list[j])):
                            if j + input_index_list[j][relative_input_index] < i + 1:
                                input_index_list[j][relative_input_index] -= 1

    print(layer_config_list)
    print(quantize_config_list)
    print(input_index_list)

    # generate net
    net = NetworkGraph(hardware_config, layer_config_list, quantize_config_list, input_index_list, reuse_config_list, prune_config_list, input_params)

    return net


if __name__ == '__main__':
    hardware_config = {'xbar_size': 128, 'input_bit': 8, 'weight_bit': 8, 'quantize_bit': 8}
    net = get_net(hardware_config, 'Vgg16', 10, 'naive')
    net.get_structure()
    net.get_weights()
    print(net.net_info)
    # print(net.net_bit_weights)
