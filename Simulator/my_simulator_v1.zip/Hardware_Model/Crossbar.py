#!/usr/bin/python
# -*-coding:utf-8-*-
import os
import configparser as cp
from Hardware_Model.Device import device
test_SimConfig_path = os.path.join(os.path.dirname(os.getcwd()), "SimConfig.ini")


class crossbar(device):
	def __init__(self, SimConfig_path):
		device.__init__(self, SimConfig_path)
		xbar_config = cp.ConfigParser()
		xbar_config.read(SimConfig_path, encoding='UTF-8')

		self.xbar_size = list(map(int, xbar_config.get('Crossbar level', 'Xbar_Size').split(',')))
		self.xbar_row = int(self.xbar_size[0])
		self.xbar_column = int(self.xbar_size[1])

		self.xbar_area = 0
		self.xbar_read_power = 0
		self.xbar_read_latency = 0
		self.xbar_read_energy = 0

		self.xbar_num_read_row = self.xbar_row
		self.xbar_num_read_column = self.xbar_column
		self.xbar_utilization = 1.0

	def calculate_xbar_area(self):
		# Area unit: um^2
		WL_ratio = 3  # WL_ratio is the technology parameter W/L of the transistor
		self.xbar_area = 3 * (WL_ratio + 1) * self.xbar_row * self.xbar_column * self.device_tech**2 * 1e-6

	def calculate_xbar_read_latency(self):
		# unit: ns
		# self.calculate_wire_resistance()
		# self.calculate_wire_capacity()
		size = self.xbar_row * self.xbar_column / 1024 / 8  # KB
		wire_latency = 0.001 * (0.0002 * size ** 2 + 5 * 10 ** -6 * size + 4 * 10 ** -14)  # ns
		self.xbar_read_latency = self.device_read_latency + wire_latency

	def calculate_xbar_read_power(self):
		# unit: W
		# cal_mode: 0: simple estimation, 1: detailed simulation
		# Notice: before calculating power, xbar_read_config must be executed
		# Assuming that in 0T1R structure, the read power of unselected cell is 1/4 of the selected cells' read power
		self.calculate_device_read_power()
		self.xbar_read_power = self.xbar_num_read_row * self.xbar_num_read_column * self.device_read_power

	def calculate_xbar_read_energy(self):
		# unit: nJ
		self.xbar_read_energy = self.xbar_read_power * self.xbar_read_latency

	def xbar_output(self):
		device.device_output(self)
		print("crossbar_size:", self.xbar_size)
		print("crossbar_area", self.xbar_area, "um^2")
		print("crossbar_utilization_rate", self.xbar_utilization)
		print("crossbar_read_power:", self.xbar_read_power, "W")
		print("crossbar_read_latency:", self.xbar_read_latency, "ns")
		print("crossbar_read_energy:", self.xbar_read_energy, "nJ")

	
def xbar_test():
	print("load file:", test_SimConfig_path)
	_xbar = crossbar(test_SimConfig_path)
	print('------------')
	_xbar.calculate_xbar_area()
	_xbar.calculate_xbar_read_latency()
	_xbar.calculate_xbar_read_power()
	_xbar.calculate_xbar_read_energy()
	_xbar.xbar_output()


if __name__ == '__main__':
	xbar_test()
